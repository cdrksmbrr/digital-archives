<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Work</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        html, body {
            height: 100%;
            margin: 0;
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #e6f2e6;
            color: #2c3e50;
            padding:40px;
        }

        .container {
            display: flex;
            flex-direction: column;
            height: 90%;
        }

        .row {
            flex-grow: 1;
            display: flex;
        }

        .col-md-9 {
            display: flex;
            flex-direction: column;
        }

        .main-content {
            flex-grow: 1;
            background-color: #fff;
            padding: 30px 50px;
            border-radius: 2px;
            box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(27, 31, 35, 0.15) 0px 0px 0px 1px;
            font-size:18px;
        }

        .steps {
            background-color: #fff;
            padding: 20px;
            box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(27, 31, 35, 0.15) 0px 0px 0px 1px;
        }

        .steps ul {
            margin: 2px;
            border: 1px solid #256b47;
            gap: 2px;
            border-radius: 1px;
        }

        .steps ul li {
            margin: 4px;
            border: 1px solid rgb(255, 255, 255);
            gap: 2px;
        }

        .steps h4 {
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 20px;
        }

        .list-group-item {
            border: none;
            padding: 15px;
            font-size: 16px;
            font-weight: bold;
        }

        .list-group-item.active {
            background-color: #2e8b57;
            color: #fff;
        }
        .text-center{
           display:flex;
           justify-content: flex-end;
           gap:20px;
           position:relative;
           top:280px;
        }
        .text-center .btn{
            border-radius:2px;
            font-size:18px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row">
            <!-- Sidebar Steps -->
            <div class="col-md-3">
                <div class="steps">
                    <h4>Steps</h4>
                    <ul class="list-group">
                        <li class="list-group-item active">1. Grant Permission</li>
                        <li class="list-group-item">2. Upload Work</li>
                        <li class="list-group-item">3. Confirm Submission</li>
                    </ul>
                </div>
            </div>

            <div class="col-md-9">
                <div class="main-content">
                    <h2>University Permission Statement</h2>
                    <p>
                            I hereby grant the UP non-exclusive worldwide, royalty-free license to reproduce, publish,
                        and publicly distribute copies of this thesis or dissertation in whatever form subject to the provisions
                        of applicable laws, the provision of the UP IPR policy and any contractual obligations, as well as more
                        specific permission marking on the Title Page. Specifically, I grant the following rights to the University:
                    </p>
                    <ul>
                        <li>To upload a copy of the work in the theses database of the college/school/institute/departments and in any other databases available on the public internet.</li>
                        <li>To publish the work in the college/school/institute/departments journal, both in print and electronic or digital format and online.</li>
                        <li>To give open access to the above-mentioned work, thus allowing "fair use" of the work in accordance with the provisions of the IPC of the Philippines (Republic Act No. 8293), especially for teaching, scholarly, and research purposes.</li>
                    </ul>
                    <div class="text-center">
                        <a href="index.html" class="btn btn-danger">I Decline</a>
                        <a href="2nd.php" class="btn btn-success">I Agree</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
