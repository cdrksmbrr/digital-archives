<?php
session_start();
include('connect.php');


// Default values
$firstName = "Guest";
$lastName = "";

// Check if email exists in the session
if (isset($_SESSION['email'])) {
    $email = $_SESSION['email'];



    // Use prepared statement
    $stmt = $conn->prepare("SELECT firstName, lastName FROM `users` WHERE email = ?");
    $stmt->bind_param("s", $email);

    if ($stmt->execute()) {
        $result = $stmt->get_result();

        // Check if user exists
        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $firstName = htmlspecialchars($row['firstName'] ?? "Unknown", ENT_QUOTES, 'UTF-8');
            $lastName = htmlspecialchars($row['lastName'] ?? "", ENT_QUOTES, 'UTF-8');
        } else {
            echo "No user found with the provided email.";
        }
    } else {
        echo "Query execution failed: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "User not logged in.";
}

?>


<?php


if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include('connect.php');
include('header.php');

$firstName = "Guest";
$lastName = "";

if (isset($_SESSION['email'])) {
    $email = $_SESSION['email'];

    $stmt = $conn->prepare("SELECT firstName, lastName FROM `users` WHERE email = ?");
    $stmt->bind_param("s", $email);

    if ($stmt->execute()) {
        $result = $stmt->get_result();

        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $firstName = htmlspecialchars($row['firstName'] ?? "Unknown", ENT_QUOTES, 'UTF-8');
            $lastName = htmlspecialchars($row['lastName'] ?? "", ENT_QUOTES, 'UTF-8');
        }
    }

    $stmt->close();
}
?>
<?php include('header.php'); ?>
<header class="bg-light border-bottom">
    <nav class="navbar navbar-expand-lg navbar-light container">
        <a class="navbar-brand fw-bold" href="#">
            <img src="include/logo.png" alt="Logo"> 
            <div>
                Digital Archives
                <small>Eastern Samar State University</small>
            </div>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="search_result.php">Search</a></li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="archivalResources" role="button" data-bs-toggle="dropdown" aria-expanded="false">Archival Resources</a>
                    <ul class="dropdown-menu" aria-labelledby="archivalResources">
                        <li><a class="dropdown-item" href="#">Personal Papers</a></li>
                        <li><a class="dropdown-item" href="#">Theses and Dissertations</a></li>
                        <li><a class="dropdown-item" href="#">University Records</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="informationDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Information</a>
                    <ul class="dropdown-menu" aria-labelledby="informationDropdown">
                        <li><a class="dropdown-item" href="#">Steps in Submitting ETDs</a></li>
                        <li><a class="dropdown-item" href="#">IR and ETD Policies</a></li>
                        <li><a class="dropdown-item" href="#">Frequently Asked Questions</a></li>
                    </ul>
                </li>
                <li>
                    <p class="nav-link">
                        Hello, <strong>
                            <?php 
                            // Display the user's name or a fallback if no user is found
                            echo $firstName . ' ' . $lastName;
                            ?>
                        </strong>
                    </p>
                </li>
                <!-- Logout button -->
                <li class="nav-item"><a class="nav-link" href="Access.php">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6" height="20" width="20">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 9V5.25A2.25 2.25 0 0 1 10.5 3h6a2.25 2.25 0 0 1 2.25 2.25v13.5A2.25 2.25 0 0 1 16.5       21h-6a2.25 2.25 0 0 1-2.25-2.25V15m-3 0-3-3m0 0 3-3m-3 3H15" />
                    </svg>
                    Logout</a>
                </li>
            </ul>
        </div>
    </nav>
</header>

<div style="font-size: 19px;" class="container pt-4">Home → Steps for Submitting ETDs </div>
<div class="container mt-5">
    <h1 class="text-center">Steps for Submitting Your Electronic Theses and Dissertations (ETDs)</h1>
    <p class="text-center text-muted">Follow these simple steps to submit your work to the Digital Archives of Eastern Samar State University.</p>

    <div class="mt-4">
        <div class="step mb-4">
            <h3 class="fw-bold">1. Grant Permission</h3>
            <div class="text-center">
                <img src="step1.png" alt="Grant Permission" class="img-fluid mb-3" style="max-width: 800px; height: auto;">
            </div>
            <p>Start by reviewing and granting the necessary permissions for your ETD. This step ensures your work complies with institutional policies and is accessible according to your chosen settings. You'll need to decide if your work should be openly available to the public, restricted to certain users, or available only within the university network.</p>
            <p>Important considerations during this step include:
                <ul>
                    <li><strong>Copyright:</strong> Ensure that you hold the rights to your work or have the necessary permissions from third-party copyright holders.</li>
                    <li><strong>License:</strong> Choose an appropriate license for your work. You may want to select a Creative Commons license or retain all rights.</li>
                    <li><strong>Embargo:</strong> If needed, set an embargo to delay public access for a specified period.</li>
                </ul>
            </p>
        </div>

        <div class="step mb-4">
            <h3 class="fw-bold">2. Describe Your Work</h3>
            <div class="text-center">
                <img src="step2.png" alt="Describe Your Work" class="img-fluid mb-3" style="max-width: 800px; height: auto;">
            </div>
            <p>Provide a detailed description of your thesis or dissertation. This is important for making your work discoverable and accessible. You'll need to include key details such as the title, abstract, keywords, and your advisor's name. The description helps others understand the scope and relevance of your work.</p>
            <p>In this step, you'll also need to:
                <ul>
                    <li><strong>Title:</strong> Provide a clear, concise title that accurately reflects the content of your work.</li>
                    <li><strong>Abstract:</strong> Write a brief summary of your research, outlining the objectives, methodology, results, and conclusions.</li>
                    <li><strong>Keywords:</strong> Add relevant keywords that will help others find your work when searching.</li>
                    <li><strong>Advisor Information:</strong> Include the name of your academic advisor and any other significant contributors.</li>
                </ul>
            </p>
        </div>

        <div class="step mb-4">
            <h3 class="fw-bold">3. Upload Your Complete ETD</h3>
            <div class="text-center">
                <img src="step3.png" alt="Upload Your Complete ETD" class="img-fluid mb-3" style="max-width: 800px; height: auto;">
            </div>
            <p>Upload the finalized version of your ETD in the required format (PDF). Double-check that all sections are complete and accurate before submission. The submission system may require you to upload several files, including the main document, supplementary materials (e.g., appendices), and any supporting data.</p>
            <p>Before uploading, make sure to:
                <ul>
                    <li><strong>Format:</strong> Ensure that your document is formatted according to the university's submission guidelines (e.g., font size, margins, pagination).</li>
                    <li><strong>File Size:</strong> Check that the file size does not exceed the system's upload limits.</li>
                    <li><strong>Supplementary Files:</strong> If your ETD includes supplementary materials, such as datasets or videos, ensure these are properly formatted and included in the submission.</li>
                    <li><strong>Final Review:</strong> Review your document one last time for any typos, formatting errors, or missing sections before submitting.</li>
                </ul>
            </p>
        </div>
    </div>

    <div class="text-center mt-5">
        <a href="form1.php" class="btn btn-primary btn-lg">Submit Your ETD</a>
    </div>
</div>




<?php include('include/footer.php'); ?>