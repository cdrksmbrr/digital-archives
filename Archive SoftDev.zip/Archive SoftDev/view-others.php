<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include('connect.php');
include('header.php');

$firstName = "Guest";
$lastName = "";

if (isset($_SESSION['email'])) {
    $email = $_SESSION['email'];

    $stmt = $conn->prepare("SELECT firstName, lastName FROM `users` WHERE email = ?");
    $stmt->bind_param("s", $email);

    if ($stmt->execute()) {
        $result = $stmt->get_result();

        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $firstName = htmlspecialchars($row['firstName'] ?? "Unknown", ENT_QUOTES, 'UTF-8');
            $lastName = htmlspecialchars($row['lastName'] ?? "", ENT_QUOTES, 'UTF-8');
        }
    }

    $stmt->close();
}
?>

<header class="bg-light border-bottom">
    <nav class="navbar navbar-expand-lg navbar-light container">
        <a class="navbar-brand fw-bold" href="#">
            <img src="include/logo.png" alt="Logo"> 
            <div>
                Digital Archives
                <small>Eastern Samar State University</small>
            </div>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="search_result.php">Search</a></li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="archivalResources" role="button" data-bs-toggle="dropdown" aria-expanded="false">Archival Resources</a>
                    <ul class="dropdown-menu" aria-labelledby="archivalResources">
                        <li><a class="dropdown-item" href="#">Personal Papers</a></li>
                        <li><a class="dropdown-item" href="#">Theses and Dissertations</a></li>
                        <li><a class="dropdown-item" href="#">University Records</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="informationDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Information</a>
                    <ul class="dropdown-menu" aria-labelledby="informationDropdown">
                        <li><a class="dropdown-item" href="#">Steps in Submitting ETDs</a></li>
                        <li><a class="dropdown-item" href="#">IR and ETD Policies</a></li>
                        <li><a class="dropdown-item" href="#">Frequently Asked Questions</a></li>
                    </ul>
                </li>
                <li>
                <p class="nav-link">
                        Hello, <strong>
                            <?php 
                            // Display the user's name or a fallback if no user is found
                            echo $firstName . ' ' . $lastName;
                            ?>
                        </strong>
                    </p>

                </li>
                <li class="nav-item"><a class="nav-link" href="Access.php">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6" height="20" width="20">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 9V5.25A2.25 2.25 0 0 1 10.5 3h6a2.25 2.25 0 0 1 2.25 2.25v13.5A2.25 2.25 0 0 1 16.5       21h-6a2.25 2.25 0 0 1-2.25-2.25V15m-3 0-3-3m0 0 3-3m-3 3H15" />
                    </svg>
                    Logout</a>
                </li>
            </ul>
        </div>
    </nav>
</header>
<div style="font-size: 19px;" class="container py-4">Home → All Uploaded Works</div>
<div class="search-part bg-light border-bottom">
    <!-- Header with Search Bar -->
    <div class="header" style="background-color: #2d4d2e; padding: 40px 0;">
        <div class="container d-flex justify-content-center align-items-center"> 
            <form action="search_result.php" method="get" class="d-flex justify-content-center align-items-center w-75">
                <!-- Search Dropdown -->
                <select name="field" class="form-select me-3" style="font-size: 1.2rem; height: auto; padding: 20px; width: 20%; border-radius: 10px 0 0 10px;">
                    <option selected>Any Field</option>
                    <option value="resource_title">Title</option>
                    <option value="personal_name">Author</option>
                    <option value="abstract">Abstract</option>
                    <option value="degree_course">Degree Course</option>
                    <option value="keywords">Keywords</option>
                </select>
                <!-- Search Input -->
                <input type="text" name="query" class="form-control me-3" placeholder="Search for..." required style="font-size: 1.2rem; height: auto; padding: 20px; width: 100%;">
                <!-- Search Button -->
                <button type="submit" style="font-size: 1.2rem; height: auto; padding: 20px; width: 10%; border-radius: 0 10px 10px 0; border:1px solid transparent; background-color: white; transition: all 0.3s ease-in-out;" onmouseover="this.style.background='#D4D4D4'" onmouseout="this.style.background='white'">
                    <!-- SVG Search Icon -->
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6" height="30" width="30">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M21 21L15.803 15.803M15.803 15.803A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607z" />
                    </svg>
                </button>
            </form>
        </div>
    </div>
</div>

<style>
.btn-outline-primary {
    color: #006400; /* Dark greenish color for text */
    border-color: #006400; /* Dark greenish color for border */
    background-color: transparent; /* Transparent background */
}

.btn-outline-primary:hover {
    color: #ffffff; /* White text on hover */
    background-color: #004d00; /* Even darker greenish color on hover */
    border-color: #004d00; /* Match the background color */
}

</style>
<div class="container my-5">
    <div style="display: flex; justify-content: center; align-items: center; ">
        <div class="text-center mb-4 d-flex align-items-center">       
            <img src="include/logo.png" alt="Logo" style="max-width: 100px; margin-right: 20px;"> 
            <div class="d-flex flex-column align-items-center">
                <h1>Digital Archives</h1>
                <small style="font-size: 1.2rem">Eastern Samar State University</small>
            </div>
        </div>
    </div>
    <div class="row" id="data-container">
        <?php
        $stmt = $conn->prepare("SELECT * FROM `insert_data` LIMIT 10");
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $resource_title = htmlspecialchars($row['resource_title']);
                $resource_abstract = htmlspecialchars($row['abstract']);
                $authors = htmlspecialchars($row['personal_name']);
                $pdf_file_path = htmlspecialchars($row['pdf_file_path']);
        ?>
                <div class="col-md-6 mb-4">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-body">
                            <!-- Research Title -->
                            <h5 class="card-title text-dark fw-bold" style="line-height: 0.9;"><?php echo $resource_title; ?></h5>

                            <!-- Authors -->
                            <p class="text-muted" style="line-height: 0.9;"><strong>Authors:</strong></p>
                            <p class="mb-3" style="line-height: 0.9;"><?php echo $authors; ?></p>

                            <!-- Abstract -->
                            <p class="text-muted" style="line-height: 0.9;"><strong>Abstract:</strong></p>
                            <p class="mb-3" style="line-height: 0.9;"><?php echo nl2br($resource_abstract); ?></p>

                            <!-- PDF Button -->
                            <div class="card border-0">
                                <div class="card-body d-flex justify-content-center align-items-center">
                                <a href="view_pdf.php?file=<?php echo urlencode($pdf_file_path); ?>" class="btn btn-outline-primary btn-lg w-90 d-flex flex-column align-items-center" style="line-height: 0.9;">
                                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6" width="200" height="200">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z" />
                                            </svg>
                                            <span class="text-muted">View PDF</span>
                                        </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        <?php
            }
        } else {
            echo "<div class='text-center text-muted'>No research proposals found.</div>";
        }
        $stmt->close();
        ?>
    </div>
    <div class="text-center mt-5">
        <button id="show-more-btn" class="btn btn-success p-3">Show More</button>
    </div>
</div>

<script>
document.getElementById('show-more-btn').addEventListener('click', function() {
    const container = document.getElementById('data-container');
    const button = this;

    let offset = container.childElementCount; // Current number of displayed items

    fetch('load_more.php?offset=' + offset)
        .then(response => response.text())
        .then(data => {
            if (data.trim() === '') {
                button.textContent = 'No More Data';
                button.disabled = true;
            } else {
                container.innerHTML += data;
            }
        })
        .catch(error => console.error('Error:', error));
});
</script>
<?php include('include/footer.php'); ?>
