<?php include('connect.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Item Submission</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f8f9fa;
}

.steps h4 {
    font-weight: bold;
    color: #333;
}

.list-group-item {
    display: flex;
    align-items: center;
    border: none;
    padding: 10px 15px;
}

.list-group-item.active {
    background-color: #ffc107;
    color: #fff;
    font-weight: bold;
}

.step-number {
    display: inline-block;
    width: 25px;
    height: 25px;
    background-color: #ffc107;
    color: white;
    font-weight: bold;
    text-align: center;
    line-height: 25px;
    border-radius: 50%;
    margin-right: 10px;
}

.content h2 {
    color: #333;
    font-weight: bold;
}

ul {
    padding-left: 20px;
}

ul li {
    margin-bottom: 10px;
}

.btn {
    width: 120px;
    font-size: 16px;
    font-weight: bold;
}

    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="row">
            <!-- Sidebar Steps -->
            <div class="col-md-3">
                <div class="steps">
                    <h4 class="mb-3">Steps</h4>
                    <ul class="list-group">
                        <li class="list-group-item active">
                            <span class="step-number">1</span> Grant Permission
                        </li>
                        <li class="list-group-item">
                            <span class="step-number">2</span> Describe Work
                        </li>
                        <li class="list-group-item">
                            <span class="step-number">3</span> Upload Files
                        </li>
                        <li class="list-group-item">
                            <span class="step-number">4</span> Confirm Submission
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-9">
                <div class="content">
                    <h2>University Permission Statement</h2>
                    <p>
                        I hereby grant the UP non-exclusive worldwide, royalty-free license to reproduce, publish,
                        and publicly distribute copies of this thesis or dissertation in whatever form subject to the provisions
                        of applicable laws, the provision of the UP IPR policy and any contractual obligations, as well as more
                        specific permission marking on the Title Page. Specifically, I grant the following rights to the University:
                    </p>
                    <ul>
                        <li>To upload a copy of the work in the theses database of the college/school/institute/departments and in any other databases available on the public internet.</li>
                        <li>To publish the work in the college/school/institute/departments journal, both in print and electronic or digital format and online.</li>
                        <li>To give open access to the above-mentioned work, thus allowing "fair use" of the work in accordance with the provisions of the IPC of the Philippines (Republic Act No. 8293), especially for teaching, scholarly, and research purposes.</li>
                    </ul>
                    <div class="text-center mt-4">
                        <a href="index.html" class="btn btn-danger">I Decline</a>
                        <a href="2nd.php" class="btn btn-success">I Agree</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
