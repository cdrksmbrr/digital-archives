<!-- Footer Section -->
<footer>
    <div class="footer-section" >
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title"><span>Contact Info</span></div>
                    <p>Digital Archives @ ESSU is hosted and maintained by the University Library, Eastern Samar State University (ESSU).</p>
                    <ul>
                        <li>
                            <span>📍 Address:</span>
                            Brgy. Baras, Borongan City, Eastern Samar, Philippines
                        </li>
                        <li>
                            <span>📞 Phone:</span>
                            (+63) 55-500-1234
                        </li>
                        <li>
                            <span>📧 Email:</span>
                            library@essu.edu.ph <br>
                            digitalarchives@essu.edu.ph
                        </li>
                        <li>
                            <span>🌐 Website:</span>
                            www.essu.edu.ph
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container d-flex justify-content-between">
            <span>Copyright © 2025 | The University Library, Eastern Samar State University</span>
            <span>
                <a href="#">Acceptable Use Policy</a> | 
                <a href="#">Privacy Policy</a>
            </span>
        </div>
    </div>
</footer>

<?php include('connect.php'); ?>
<form action="insert_data.php" method="POST" enctype="multipart/form-data">
  <div class="modal" id="myModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add New Items</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">
                <!-- Form fields -->
                <div class="form-group">
                    <label for="arch_personal_name" class="form-label">Authors</label>
                    <div id="authors-container">
                        <div class="author-input">
                            <input type="text" name="arch_personal_name[]" class="form-control mb-2" placeholder="Author Name" required>
                        </div>
                    </div>
                    <button type="button" class="btn btn-link" id="add-author-btn">
                        <span class="bi bi-plus-circle"></span> Add Author
                    </button>
                    <small class="form-text text-muted">Click the plus sign to add more authors.</small>
                </div>

                <div class="form-group mt-3">
                    <label for="arch_resource_title" class="form-label">Resource Title</label>
                    <input type="text" name="arch_resource_title" class="form-control" required>
                </div>

                <div class="form-group mt-3">
                    <label for="arch_abstract" class="form-label">Abstract</label>
                    <textarea name="arch_abstract" class="form-control" rows="3" required></textarea>
                </div>

                <div class="form-group mt-3">
                    <label for="arch_degree_course" class="form-label">Degree Course</label>
                    <select name="arch_degree_course" class="form-control" required>
                        <option value="">Select Course</option>
                        <option value="Computer Science">Computer Science</option>
                        <option value="Electrical Engineering">Electrical Engineering</option>
                        <option value="Mechanical Engineering">Mechanical Engineering</option>
                        <option value="Civil Engineering">Civil Engineering</option>
                        <option value="Business Administration">Business Administration</option>
                        <option value="Economics">Economics</option>
                    </select>
                </div>

                <div class="form-group mt-3">
                    <label for="arch_keywords" class="form-label">Keywords</label>
                    <div id="keywords-container">
                        <div class="keyword-input">
                            <input type="text" name="arch_keywords[]" class="form-control mb-2" placeholder="Keyword" required>
                        </div>
                    </div>
                    <button type="button" class="btn btn-link" id="add-keyword-btn">
                        <span class="bi bi-plus-circle"></span> Add Keyword
                    </button>
                    <small class="form-text text-muted">Click the plus sign to add more keywords.</small>
                </div>

                <div class="form-group mt-3">
                    <label for="arch_pdf_file" class="form-label">Upload PDF</label>
                    <input type="file" name="arch_pdf_file" accept="application/pdf" class="form-control" required>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                <input type="submit" class="btn btn-success" name="personal_data_submit" value="Data Submit">
            </div>
        </div>
    </div>
  </div>
</form>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

<script>
    // Add new author input when the plus button is clicked
    document.getElementById('add-author-btn').addEventListener('click', function() {
        var authorsContainer = document.getElementById('authors-container');
        var newAuthorInput = document.createElement('div');
        newAuthorInput.classList.add('author-input');
        newAuthorInput.innerHTML = '<input type="text" name="arch_personal_name[]" class="form-control mb-2" placeholder="Author Name" required>';
        authorsContainer.appendChild(newAuthorInput);
    });

    // Add new keyword input when the plus button is clicked
    document.getElementById('add-keyword-btn').addEventListener('click', function() {
        var keywordsContainer = document.getElementById('keywords-container');
        var newKeywordInput = document.createElement('div');
        newKeywordInput.classList.add('keyword-input');
        newKeywordInput.innerHTML = '<input type="text" name="arch_keywords[]" class="form-control mb-2" placeholder="Keyword" required>';
        keywordsContainer.appendChild(newKeywordInput);
    });
</script>

<script>
    const signUpButton=document.getElementById('signUpButton');
const signInButton=document.getElementById('signInButton');
const signInForm=document.getElementById('signIn');
const signUpForm=document.getElementById('signup');

signUpButton.addEventListener('click',function(){
    signInForm.style.display="none";
    signUpForm.style.display="block";
})
signInButton.addEventListener('click', function(){
    signInForm.style.display="block";
    signUpForm.style.display="none";
})
</script>
<script>
    document.getElementById('signUpButton').addEventListener('click', function() {
        document.getElementById('signup').style.display = 'block';
        document.getElementById('signIn').style.display = 'none';
    });

    document.getElementById('signInButton').addEventListener('click', function() {
        document.getElementById('signup').style.display = 'none';
        document.getElementById('signIn').style.display = 'block';
    });
</script>

</body>
</html>
