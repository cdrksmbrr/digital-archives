<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Handle file upload
    $pdf_file = $_FILES['arch_pdf_file'];
    $file_name = $pdf_file['name'];
    $file_tmp = $pdf_file['tmp_name'];
    $file_size = $pdf_file['size'];
    $file_error = $pdf_file['error'];
    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

    if ($file_error === 0) {
        if ($file_ext === 'pdf') {
            if ($file_size <= 5000000) { // Limit to 5MB
                $new_file_name = uniqid('', true) . '.' . $file_ext;
                $file_destination = 'uploads/' . $new_file_name;

                if (move_uploaded_file($file_tmp, $file_destination)) {
                    echo "PDF file uploaded successfully! File path: " . $file_destination;
                } else {
                    echo "Failed to upload the file.";
                }
            } else {
                echo "File size exceeds the limit of 5MB.";
            }
        } else {
            echo "Only PDF files are allowed.";
        }
    } else {
        echo "There was an error uploading the file.";
    }
}
?>