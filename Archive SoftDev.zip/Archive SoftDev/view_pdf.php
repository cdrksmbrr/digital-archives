<?php
// Check if the file parameter is passed
if (isset($_GET['file'])) {
    $filePath = urldecode($_GET['file']);

    // Make sure the file exists
    if (file_exists($filePath)) {
        // Set the appropriate headers to display the PDF in the browser
        header('Content-Type: application/pdf');
        header('Content-Disposition: inline; filename="' . basename($filePath) . '"');
        header('Content-Length: ' . filesize($filePath));

        // Read and output the file
        readfile($filePath);
        exit();
    } else {
        echo "File not found.";
    }
} else {
    echo "No file specified.";
}
?>
