<?php
// Start the session at the very beginning of the file
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    // If the user is not logged in, redirect to login page
    header("Location: login.php");
    exit();
}

// Include necessary files
include('connect.php');
include('header.php'); // Make sure this file has no output before this line

// Check if a delete request is made
if (isset($_GET['data_id'])) {
    // Get the data_id from the URL
    $data_id = $_GET['data_id'];

    // Prepare the DELETE query
    $query = "DELETE FROM `insert_data` WHERE `data_id` = '$data_id' AND `user_id` = '" . $_SESSION['user_id'] . "'";

    // Execute the query
    if ($conn->query($query) === TRUE) {
        // If the deletion was successful, redirect with success message
        header("Location:  view-uploads.php?message_success=");
        exit();
    } else {
        // If there was an error with the deletion, redirect with an error message
        header("Location:  view-uploads.php?message=Error deleting record");
        exit();
    }
}

?>

<?php


// Default values
$firstName = "Guest";
$lastName = "";

// Check if email exists in the session
if (isset($_SESSION['email'])) {
    $email = $_SESSION['email'];



    // Use prepared statement
    $stmt = $conn->prepare("SELECT firstName, lastName FROM `users` WHERE email = ?");
    $stmt->bind_param("s", $email);

    if ($stmt->execute()) {
        $result = $stmt->get_result();

        // Check if user exists
        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $firstName = htmlspecialchars($row['firstName'] ?? "Unknown", ENT_QUOTES, 'UTF-8');
            $lastName = htmlspecialchars($row['lastName'] ?? "", ENT_QUOTES, 'UTF-8');
        } else {
            echo "No user found with the provided email.";
        }
    } else {
        echo "Query execution failed: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "User not logged in.";
}

?>


<header class="bg-light border-bottom">
    <nav class="navbar navbar-expand-lg navbar-light container">
        <a class="navbar-brand fw-bold" href="#">
            <img src="include/logo.png" alt="Logo"> 
            <div>
                Digital Archives
                <small>Eastern Samar State University</small>
            </div>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Search</a></li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="archivalResources" role="button" data-bs-toggle="dropdown" aria-expanded="false">Archival Resources</a>
                    <ul class="dropdown-menu" aria-labelledby="archivalResources">
                        <li><a class="dropdown-item" href="#">Personal Papers</a></li>
                        <li><a class="dropdown-item" href="#">Theses and Dissertations</a></li>
                        <li><a class="dropdown-item" href="#">University Records</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="informationDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Information</a>
                    <ul class="dropdown-menu" aria-labelledby="informationDropdown">
                        <li><a class="dropdown-item" href="#">Steps in Submitting ETDs</a></li>
                        <li><a class="dropdown-item" href="#">IR and ETD Policies</a></li>
                        <li><a class="dropdown-item" href="#">Frequently Asked Questions</a></li>
                    </ul>
                </li>
                <li>
                <p class="nav-link">
                        Hello, <strong>
                            <?php 
                            // Display the user's name or a fallback if no user is found
                            echo $firstName . ' ' . $lastName;
                            ?>
                        </strong>
                    </p>

                </li>
                <li class="nav-item"><a class="nav-link" href="Access.php">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6" height="20" width="20">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 9V5.25A2.25 2.25 0 0 1 10.5 3h6a2.25 2.25 0 0 1 2.25 2.25v13.5A2.25 2.25 0 0 1 16.5       21h-6a2.25 2.25 0 0 1-2.25-2.25V15m-3 0-3-3m0 0 3-3m-3 3H15" />
                    </svg>
                    Logout</a>
                </li>
            </ul>
        </div>
    </nav>
</header>
<div style="font-size: 19px;" class="container p-2">Home → My Works</div>
<div class="container" style="margin-bottom:520px">


    <div class="row mt-4">
        <?php
            // Get the user_id from the session
            $user_id = $_SESSION['user_id'];

            // Query to fetch only records that belong to the logged-in user
            $query = "SELECT * FROM `insert_data` WHERE `user_id` = '$user_id'";
            $result = $conn->query($query);

            // Check if there are any results
            if ($result->num_rows > 0) {
                // Loop through the results and display them as cards
                while ($row = $result->fetch_assoc()) {
                    $resource_title = $row['resource_title'];
                    $resource_abstract = $row['abstract'];
                    $degree_course = $row['degree_course'];
                    $keywords = $row['keywords'];
                    $pdf_file_path = $row['pdf_file_path'];
                    $authors = explode(',', $row['personal_name']);  // Assuming authors are stored as comma-separated values

                    // Display the resource and authors in a card format
                    echo "<div class='col-12 col-md-6 mb-4'>";  
                    echo "<div class='card h-100 border-0 shadow-sm rounded-3'>";

                    echo "<div class='card-body p-3'>";

                    // Resource Title
                    echo "<h5 style='text-transform: uppercase; font-weight: bold; line-height: 5px;'>" . strtoupper(htmlspecialchars($resource_title)) . "</h5>";
                    echo "<p>Title</p>";

                    // Authors (loop through authors array and display up to 5 authors)
                    echo "<p class='card-text text-muted'><strong>Authors:</strong><br>";
                    for ($i = 0; $i < min(count($authors), 5); $i++) {
                        echo htmlspecialchars($authors[$i]) . "<br>";
                    }
                    echo "</p>";

                    // Abstract
                    echo "<p class='card-text text-muted'><strong>Abstract:</strong><br>" . nl2br(htmlspecialchars($resource_abstract)) . "</p>";

                    // Degree Course
                    echo "<p class='card-text text-muted'><strong>Degree Course:</strong><br>" . htmlspecialchars($degree_course) . "</p>";

                    // Keywords
                    echo "<p class='card-text text-muted'><strong>Keywords:</strong><br>" . htmlspecialchars($keywords) . "</p>";

                    // PDF link
                    echo "<div class='d-flex justify-content-center'>";
                    echo "<a href='view_pdf.php?file=" . urlencode($pdf_file_path) . "' class='btn btn-primary btn-sm mx-1'>View PDF</a>";
                    echo "<a href='view-uploads.php?data_id=" . $row['data_id'] . "' class='btn btn-danger btn-sm mx-1'>Delete</a>";
                    echo "</div>";

                    echo "</div>";
                    echo "</div>";
                    echo "</div>";
                }
            } else {
                echo "<p class='text-center col-12 text-muted'>No results found.</p>";
            }
        ?>
    </div>
</div>



<?php include('include/footer.php'); ?>
