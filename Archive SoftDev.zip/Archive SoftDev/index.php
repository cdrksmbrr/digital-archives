<?php
session_start();
include('connect.php');


// Default values
$firstName = "Guest";
$lastName = "";

// Check if email exists in the session
if (isset($_SESSION['email'])) {
    $email = $_SESSION['email'];



    // Use prepared statement
    $stmt = $conn->prepare("SELECT firstName, lastName FROM `users` WHERE email = ?");
    $stmt->bind_param("s", $email);

    if ($stmt->execute()) {
        $result = $stmt->get_result();

        // Check if user exists
        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $firstName = htmlspecialchars($row['firstName'] ?? "Unknown", ENT_QUOTES, 'UTF-8');
            $lastName = htmlspecialchars($row['lastName'] ?? "", ENT_QUOTES, 'UTF-8');
        } else {
            echo "No user found with the provided email.";
        }
    } else {
        echo "Query execution failed: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "User not logged in.";
}

?>


<?php


if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include('connect.php');
include('header.php');

$firstName = "Guest";
$lastName = "";

if (isset($_SESSION['email'])) {
    $email = $_SESSION['email'];

    $stmt = $conn->prepare("SELECT firstName, lastName FROM `users` WHERE email = ?");
    $stmt->bind_param("s", $email);

    if ($stmt->execute()) {
        $result = $stmt->get_result();

        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $firstName = htmlspecialchars($row['firstName'] ?? "Unknown", ENT_QUOTES, 'UTF-8');
            $lastName = htmlspecialchars($row['lastName'] ?? "", ENT_QUOTES, 'UTF-8');
        }
    }

    $stmt->close();
}
?>

<?php include('header.php'); ?>

<header class="bg-light border-bottom">
    <nav class="navbar navbar-expand-lg navbar-light container">
        <a class="navbar-brand fw-bold" href="#">
            <img src="include/logo.png" alt="Logo"> 
            <div>
                Digital Archives
                <small>Eastern Samar State University</small>
            </div>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="search_result.php">Search</a></li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="archivalResources" role="button" data-bs-toggle="dropdown" aria-expanded="false">Archival Resources</a>
                    <ul class="dropdown-menu" aria-labelledby="archivalResources">
                        <li><a class="dropdown-item" href="#">Personal Papers</a></li>
                        <li><a class="dropdown-item" href="#">Theses and Dissertations</a></li>
                        <li><a class="dropdown-item" href="#">University Records</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="informationDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Information</a>
                    <ul class="dropdown-menu" aria-labelledby="informationDropdown">
                        <li><a class="dropdown-item" href="#">Steps in Submitting ETDs</a></li>
                        <li><a class="dropdown-item" href="#">IR and ETD Policies</a></li>
                        <li><a class="dropdown-item" href="#">Frequently Asked Questions</a></li>
                    </ul>
                </li>
                <li>
                <p class="nav-link">
                        Hello, <strong>
                            <?php 
                            // Display the user's name or a fallback if no user is found
                            echo $firstName . ' ' . $lastName;
                            ?>
                        </strong>
                    </p>

                </li>
                <li class="nav-item"><a class="nav-link" href="Access.php">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6" height="20" width="20">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 9V5.25A2.25 2.25 0 0 1 10.5 3h6a2.25 2.25 0 0 1 2.25 2.25v13.5A2.25 2.25 0 0 1 16.5       21h-6a2.25 2.25 0 0 1-2.25-2.25V15m-3 0-3-3m0 0 3-3m-3 3H15" />
                    </svg>
                    Logout</a>
                </li>
            </ul>
        </div>
    </nav>
</header>
<div class="search-part bg-light border-bottom">
    <!-- Header with Search Bar -->
    <div class="header" style="background-color: #2d4d2e; padding: 40px 0;">
        <div class="container d-flex justify-content-center align-items-center"> 
            <form action="search_result.php" method="get" class="d-flex justify-content-center align-items-center w-75">
                <!-- Search Dropdown -->
                <select name="field" class="form-select me-3" style="font-size: 1.2rem; height: auto; padding: 20px; width: 20%; border-radius: 10px 0 0 10px;">
                    <option selected>Any Field</option>
                    <option value="resource_title">Title</option>
                    <option value="personal_name">Author</option>
                    <option value="abstract">Abstract</option>
                    <option value="degree_course">Degree Course</option>
                    <option value="keywords">Keywords</option>
                </select>
                <!-- Search Input -->
                <input type="text" name="query" class="form-control me-3" placeholder="Search for..." required style="font-size: 1.2rem; height: auto; padding: 20px; width: 100%;">
                <!-- Search Button -->
                <button type="submit" style="font-size: 1.2rem; height: auto; padding: 20px; width: 10%; border-radius: 0 10px 10px 0; border:1px solid transparent; background-color: white; transition: all 0.3s ease-in-out;" onmouseover="this.style.background='#D4D4D4'" onmouseout="this.style.background='white'">
                    <!-- SVG Search Icon -->
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6" height="30" width="30">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M21 21L15.803 15.803M15.803 15.803A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607z" />
                    </svg>
                </button>
            </form>
        </div>
    </div>
</div>
<!-- Main Content Section -->
<div class="content container">
    <div class="row justify-content-center align-items-stretch">
        <div class="col-md-3 d-flex">
            <a href="form1.php" class="card h-100 text-decoration-none text-dark">
                <div class="card-icon">🏛️</div>
                <h5 class="card-title">Deposit Your Work</h5>
                <p class="card-text">
                    Click here to upload your Theses and Dissertations to the Eastern Samar State University Digital Archives.
                </p>
            </a>
        </div>
        <div class="col-md-3 d-flex">
            <a href="view-others.php" class="card h-100 text-decoration-none text-dark">
                <div class="card-icon">📊</div>
                <h5 class="card-title">All Uploaded Work</h5>
                <p class="card-text">
                    View all the work uploaded by other users to the Eastern Samar State University Digital Archives.
                </p>
            </a>
        </div>
        <div class="col-md-3 d-flex">
            <a href="view-uploads.php" class="card h-100 text-decoration-none text-dark">
                <div class="card-icon">📂</div>
                <h5 class="card-title">My Work</h5>
                <p class="card-text">
                    Access and review the work you have uploaded to the Eastern Samar State University Digital Archives.
                </p>
            </a>
        </div>

            <div class="col-md-3 d-flex">
            <a href="submitting-steps.php" class="card h-100 text-decoration-none text-dark">
                <div class="card-icon">📋</div>
                <h5 class="card-title">Steps in Submitting ETDs</h5>
                <p class="card-text">
                    Learn the submission process for your ETDs at Eastern Samar State University.
                </p>
            </a>
        </div>
    </div>
</div>

<div class="hero-section">
    <div class="hero-overlay"></div>
    <div class="hero-content">
        <h1 class="hero-title">Welcome to the Digital Archives @ ESSU</h1>
        <p class="hero-description">
            The official Institutional Repository of Eastern Samar State University, preserving the university's rich academic history and research legacy.
            Our digital archives serve as a central hub for the university’s scholarly output, including theses, dissertations, research papers, and institutional records. 
            We aim to provide easy, secure access to the digital memory of ESSU, supporting research, learning, and academic collaboration.
        </p>
        <a href="#about-us" class="btn btn-light hero-btn">Learn More</a>
    </div>
</div>

<!-- Archival Resources Section -->
<div class="resources-section">
    <div class="container">
        <div class="row resources-container">
            <div class="col-md-6">
                <div class="section-title"><span>Archival Resources Available</span></div>
                <ul class="list-group">
                    <li class="list-group-item">Personal Papers (997)</li>
                    <li class="list-group-item">Presidential Papers</li>
                    <li class="list-group-item">Theses and Dissertations (4,943)</li>
                    <li class="list-group-item">University Records (1)</li>
                    <li class="list-group-item">UPIANA (228)</li>
                </ul>
            </div>
            <div class="col-md-6">
                <div class="section-title"><span>Recent Submissions</span></div>
                <ul class="list-group recent-submissions">
                    <li class="list-group-item">
                        <span class="icon">📄</span>
                        Recent Project Submission Title 1
                        <span class="float-end">+</span>
                    </li>
                    <li class="list-group-item">
                        <span class="icon">📄</span>
                        Recent Project Submission Title 2
                        <span class="float-end">+</span>
                    </li>
                </ul>
            </div>
        </div>
        <nav aria-label="Page navigation" class="mt-4">
            <ul class="pagination">
                <li class="page-item">
                    <a class="page-link" href="#" aria-label="Previous">&laquo;</a>
                </li>
                <li class="page-item active"><a class="page-link" href="#">1</a></li>
                <li class="page-item"><a class="page-link" href="#">2</a></li>
                <li class="page-item"><a class="page-link" href="#">3</a></li>
                <li class="page-item"><a class="page-link" href="#">4</a></li>
                <li class="page-item"><a class="page-link" href="#">5</a></li>
                <li class="page-item">
                    <a class="page-link" href="#" aria-label="Next">&raquo;</a>
                </li>
            </ul>
        </nav>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>

<?php include('include/footer.php'); ?>
