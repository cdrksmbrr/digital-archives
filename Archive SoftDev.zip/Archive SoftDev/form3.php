<?php 
session_start();
include('connect.php');

// Default values
$firstName = "Guest";
$lastName = "";

// Check if email exists in the session
if (isset($_SESSION['email'])) {
    $email = $_SESSION['email'];

    // Use prepared statement
    $stmt = $conn->prepare("SELECT firstName, lastName FROM `users` WHERE email = ?");
    $stmt->bind_param("s", $email);

    if ($stmt->execute()) {
        $result = $stmt->get_result();

        // Check if user exists
        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $firstName = htmlspecialchars($row['firstName'] ?? "Unknown", ENT_QUOTES, 'UTF-8');
            $lastName = htmlspecialchars($row['lastName'] ?? "", ENT_QUOTES, 'UTF-8');
        } else {
            echo "No user found with the provided email.";
        }
    } else {
        echo "Query execution failed: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "User not logged in.";
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review Your Work</title> <!-- Changed title -->
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
    body {font-family: 'Segoe UI', sans-serif; background-color: #e6f2e6; color: #2c3e50;}
    .container {margin-top: 0px;}
    .steps {background-color: #fff; padding: 20px; box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(27, 31, 35, 0.15) 0px 0px 0px 1px;}
    .steps ul {margin: 2px; border: 1px solid #256b47; gap: 2px; border-radius: 1px;}
    .steps ul li {margin: 4px; border: 1px solid #fff; gap: 2px;}
    .steps h4, .form-section h4 {font-weight: bold; color: #2c3e50; margin-bottom: 20px;}
    .list-group-item {border: none; padding: 15px; font-size: 16px; font-weight: bold;}
    .list-group-item.active {background-color: #2e8b57; color: #fff;}
    .form-label {font-weight: 600; color: #2c3e50;}
    .btn {font-size: 16px; font-weight: bold; ; color: white; text-decoration: none; margin:4px;}
    .btn:hover {opacity: 0.8; transform: scale(1.1); color: white;}
    .form-section {background-color: #fff; padding: 30px; border-radius: 2px; box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(27, 31, 35, 0.15) 0px 0px 0px 1px;}
    .form-control, .form-select {border-radius: 5px;}
    .navbar-brand {display: flex; align-items: center; font-size: 1.5rem; color: #2a4d2d; text-decoration: none;}
    .navbar-brand img {height: 40px; margin-right: 10px;}
    .navbar-brand small {display: block; font-size: 0.8rem; color: #555; margin-top: -5px;}
    .nav-link {color: #2a4d2d; font-weight: 500; transition: color 0.3s;}
    .nav-item .sign-in {color: #fff; background: #2a4d2d; padding: 5px 10px; border-radius: 1px; margin-left: 4px;}
    .nav-item .sign-in:hover {background: #1d3c25;}
    .header {background: #2d6a4f; padding: 10px 0;}
    .header .search-bar {display: flex; align-items: center; justify-content: center; gap: 10px;}
    .header .form-select, .header .form-control, .header .btn {border-radius: 2px; padding: 10px 20px;}
    .header .btn {background: #fff; color: #1e4b33;}
    .header .btn:hover {background: #1e4b33; color: #fff;}
    .content {margin-top: 30px;}
  
    .footer-section {background: #2d4d2e; color: #fff; padding: 40px 20px;}
    .footer-section .section-title {font-size: 1.25rem; font-weight: bold; color: #fff; margin-bottom: 10px;}
    .footer-section .section-title span {color: #6b8e23; border-bottom: 3px solid #6b8e23; display: inline-block;}
    .footer-section p, .footer-section ul {margin: 0 0 10px; padding: 0; list-style: none; font-size: 0.9rem;}
    .footer-section ul li {margin-bottom: 5px; display: flex; align-items: center;}
    .footer-section ul li span {font-weight: bold; margin-right: 10px; width: 90px;}
    .footer-bottom {background: #1e3c28; color: #fff; padding: 10px 20px; font-size: 0.8rem; text-align: center;}
    .footer-bottom a {color: #6b8e23; text-decoration: none;}
    .footer-bottom a:hover {text-decoration: underline;}
    </style>
</head>
<body>

<header class="bg-light border-bottom">
    <nav class="navbar navbar-expand-lg navbar-light container">
        <a class="navbar-brand fw-bold" href="#">
            <img src="include/logo.png" alt="Logo"> 
            <div>
                Digital Archives
                <small>Eastern Samar State University</small>
            </div>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="search_result.php">Search</a></li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="archivalResources" role="button" data-bs-toggle="dropdown" aria-expanded="false">Archival Resources</a>
                    <ul class="dropdown-menu" aria-labelledby="archivalResources">
                        <li><a class="dropdown-item" href="#">Personal Papers</a></li>
                        <li><a class="dropdown-item" href="#">Theses and Dissertations</a></li>
                        <li><a class="dropdown-item" href="#">University Records</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="informationDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Information</a>
                    <ul class="dropdown-menu" aria-labelledby="informationDropdown">
                        <li><a class="dropdown-item" href="#">Steps in Submitting ETDs</a></li>
                        <li><a class="dropdown-item" href="#">IR and ETD Policies</a></li>
                        <li><a class="dropdown-item" href="#">Frequently Asked Questions</a></li>
                    </ul>
                </li>
                <li>
                    <p class="nav-link">
                    Hello, <strong>
                            <?php 
                            // Display the user's name or a fallback if no user is found
                            echo $firstName . ' ' . $lastName;
                            ?>
                        </strong>
                    </p>
                </li>
                <li class="nav-item"><a class="nav-link" href="Access.php">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6" height="20" width="20">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 9V5.25A2.25 2.25 0 0 1 10.5 3h6a2.25 2.25 0 0 1 2.25 2.25v13.5A2.25 2.25 0 0 1 16.5       21h-6a2.25 2.25 0 0 1-2.25-2.25V15m-3 0-3-3m0 0 3-3m-3 3H15" />
                    </svg>
                    Logout</a>
                </li>
            </ul>
        </div>
    </nav>
</header>
<div style="font-size: 19px;" class="container pt-4">Home → Step 3 : Uploaded Complete </div>
    <div class="container mt-5 mb-5">
        <div class="row">
            <!-- Sidebar Steps -->
            <div class="col-md-3">
                <div class="steps">
                    <h4>Steps</h4>
                    <ul class="list-group">
                        <li class="list-group-item">1. Confirm Submission</li> <!-- Changed step 1 -->
                        <li class="list-group-item ">2. Upload Work</li>
                        <li class="list-group-item active">3. Uploaded Complete</li> <!-- Changed step 3 -->
                    </ul>
                </div>
            </div>

            <div class="col-md-9">
    <div class="row justify-content-center">
        <?php
            // Get the user_id from the session
            $user_id = $_SESSION['user_id'];

            // Query to fetch the latest record for the logged-in user, ordered by the creation date
            $query = "SELECT * FROM `insert_data` WHERE `user_id` = '$user_id' ORDER BY `created_at` DESC LIMIT 1";
            $result = $conn->query($query);

            // Check if there are any results
            if ($result->num_rows > 0) {
                // Fetch the latest record
                $row = $result->fetch_assoc();
                $resource_title = $row['resource_title'];
                $resource_abstract = $row['abstract'];
                $degree_course = $row['degree_course'];
                $keywords = $row['keywords'];
                $pdf_file_path = $row['pdf_file_path'];
                $authors = explode(',', $row['personal_name']); // Assuming authors are stored as comma-separated values
        ?>
        <div class="col-md-12 p-5" style="background-color: white; box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(27, 31, 35, 0.15) 0px 0px 0px 1px;">
            <div class="text-center">
                <!-- Title -->
                <h5 style="text-transform: uppercase; font-weight: bold; line-height: 5px;"> <?php echo strtoupper(htmlspecialchars($resource_title)); ?></h5>
                <p>Title</p>

                <!-- Authors -->
                <p class="mb-4">
                    <strong>Authors:</strong><br>
                    <?php 
                        for ($i = 0; $i < min(count($authors), 20); $i++) {
                            echo htmlspecialchars($authors[$i]) . "<br>";
                        }
                    ?>
                </p>

                <!-- Degree Course -->
                <p class="mb-4">
                    <strong>Degree Course:</strong><br>
                    <?php echo htmlspecialchars($degree_course); ?>
                </p>

                <!-- Abstract -->
                <p class="mb-4">
                    <strong>Abstract:</strong><br>
                    <?php echo nl2br(htmlspecialchars($resource_abstract)); ?>
                </p>

                <!-- PDF Link -->
                <a href="view_pdf.php?file=<?php echo urlencode($pdf_file_path); ?>" class="btn btn-primary mt-3">View PDF</a>

                <!-- Back to Home Button -->
                <a href="index.php" class="btn btn-secondary mt-3 ml-3">Back to Home</a> <!-- Adjust 'index.php' if necessary -->

            </div>
        </div>
        <?php
            } else {
                echo "<p class='text-center col-12'>No results found.</p>";
            }
        ?>
    </div>
</div>

        </div>
    </div>
    <?php include('include/footer.php'); ?>