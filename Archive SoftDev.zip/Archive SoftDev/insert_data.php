<?php
// Start the session to get the user ID
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    // If not logged in, redirect to login page or show an error
    header("Location: login.php");
    exit();
}

// Get the user ID from the session
$user_id = $_SESSION['user_id'];

// Connect to the database
include('connect.php');

// Check if the form is submitted
if (isset($_POST['personal_data_submit'])) {
    // Collect form data
    $personal_name = implode(", ", $_POST['arch_personal_name']); // Convert array to comma-separated string
    $resource_title = mysqli_real_escape_string($conn, $_POST['arch_resource_title']);
    $abstract = mysqli_real_escape_string($conn, $_POST['arch_abstract']);
    $degree_course = mysqli_real_escape_string($conn, $_POST['arch_degree_course']);
    $keywords = implode(", ", $_POST['arch_keywords']); // Convert array to comma-separated string

    // Handle file upload
    if (isset($_FILES['arch_pdf_file'])) {
        $file_name = $_FILES['arch_pdf_file']['name'];
        $file_tmp = $_FILES['arch_pdf_file']['tmp_name'];
        $file_size = $_FILES['arch_pdf_file']['size'];
        $file_error = $_FILES['arch_pdf_file']['error'];

        if ($file_error === 0) {
            // Set file destination
            $upload_dir = 'uploads/';
            $file_path = $upload_dir . basename($file_name);

            // Move the uploaded file to the server
            if (move_uploaded_file($file_tmp, $file_path)) {
                // Insert data into the database with user_id
                $query = "INSERT INTO insert_data (user_id, personal_name, resource_title, abstract, degree_course, keywords, pdf_file_path) 
                          VALUES ('$user_id', '$personal_name', '$resource_title', '$abstract', '$degree_course', '$keywords', '$file_path')";

                if (mysqli_query($conn, $query)) {
                    echo "Data inserted successfully!";
                    header("Location: form3.php");
                } else {
                    echo "Error: " . mysqli_error($conn);
                }
            } else {
                echo "Error uploading file.";
            }
        } else {
            echo "Error in file upload.";
        }
    }
}

mysqli_close($conn);
?>
