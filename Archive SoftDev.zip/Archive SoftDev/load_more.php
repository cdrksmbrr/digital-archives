<?php
session_start();
include('connect.php');

$offset = isset($_GET['offset']) ? intval($_GET['offset']) : 0;

$stmt = $conn->prepare("SELECT * FROM `insert_data` LIMIT 10 OFFSET ?");
$stmt->bind_param("i", $offset);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $resource_title = htmlspecialchars($row['resource_title']);
        $resource_abstract = htmlspecialchars($row['abstract']);
        $authors = htmlspecialchars($row['personal_name']);
        $pdf_file_path = htmlspecialchars($row['pdf_file_path']);
?>
                      <div class="col-md-6 mb-4">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-body">
                            <!-- Research Title -->
                            <h5 class="card-title text-dark fw-bold" style="line-height: 0.9;"><?php echo $resource_title; ?></h5>

                            <!-- Authors -->
                            <p class="text-muted" style="line-height: 0.9;"><strong>Authors:</strong></p>
                            <p class="mb-3" style="line-height: 0.9;"><?php echo $authors; ?></p>

                            <!-- Abstract -->
                            <p class="text-muted" style="line-height: 0.9;"><strong>Abstract:</strong></p>
                            <p class="mb-3" style="line-height: 0.9;"><?php echo nl2br($resource_abstract); ?></p>

                            <!-- PDF Button -->
                            <div class="card border-0">
                                <div class="card-body d-flex justify-content-center align-items-center">
                                <a href="view_pdf.php?file=<?php echo urlencode($pdf_file_path); ?>" class="btn btn-outline-primary btn-lg w-90 d-flex flex-column align-items-center" style="line-height: 0.9;">
                                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6" width="200" height="200">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z" />
                                            </svg>
                                            <span class="text-muted">View PDF</span>
                                        </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
<?php
    }
} else {
    echo ''; // No more data
}

$stmt->close();
?>
