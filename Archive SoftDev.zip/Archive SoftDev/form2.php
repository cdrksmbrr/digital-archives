<?php
session_start();
include('connect.php');



// Default values
$firstName = "Guest";
$lastName = "";

// Check if email exists in the session
if (isset($_SESSION['email'])) {
    $email = $_SESSION['email'];



    // Use prepared statement
    $stmt = $conn->prepare("SELECT firstName, lastName FROM `users` WHERE email = ?");
    $stmt->bind_param("s", $email);

    if ($stmt->execute()) {
        $result = $stmt->get_result();

        // Check if user exists
        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $firstName = htmlspecialchars($row['firstName'] ?? "Unknown", ENT_QUOTES, 'UTF-8');
            $lastName = htmlspecialchars($row['lastName'] ?? "", ENT_QUOTES, 'UTF-8');
        } else {
            echo "No user found with the provided email.";
        }
    } else {
        echo "Query execution failed: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "User not logged in.";
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Work</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
    body {font-family: 'Segoe UI', sans-serif; background-color: #e6f2e6; color: #2c3e50;}
    .container {margin-top: 0px;}
    .steps {background-color: #fff; padding: 20px; box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(27, 31, 35, 0.15) 0px 0px 0px 1px;}
    .steps ul {margin: 2px; border: 1px solid #256b47; gap: 2px; border-radius: 1px;}
    .steps ul li {margin: 4px; border: 1px solid #fff; gap: 2px;}
    .steps h4, .form-section h4 {font-weight: bold; color: #2c3e50; margin-bottom: 20px;}
    .list-group-item {border: none; padding: 15px; font-size: 16px; font-weight: bold;}
    .list-group-item.active {background-color: #2e8b57; color: #fff;}
    .form-label {font-weight: 600; color: #2c3e50;}
    .btn {font-size: 16px; font-weight: bold; background-color: #fcfcfc; color: white; text-decoration: none;}
    .btn:hover {background-color: #256b47; color: white; }
    .add-author-btn, .add-keyword-btn {border: 1px solid #256b47; border-radius:0px; padding:15px; }
    .submit-btn {background-color: #256b47; color: white;  border-radius:0px; padding:15px;}
    textarea {resize: none;}
    .form-section {background-color: #fff; padding: 30px; border-radius: 1px; box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(27, 31, 35, 0.15) 0px 0px 0px 1px;}
    .form-control, .form-select {border-radius: 5px;}
    .navbar-brand {display: flex; align-items: center; font-size: 1.5rem; color: #2a4d2d; text-decoration: none;}
    .navbar-brand img {height: 40px; margin-right: 10px;}
    .navbar-brand small {display: block; font-size: 0.8rem; color: #555; margin-top: -5px;}
    .nav-link {color: #2a4d2d; font-weight: 500; transition: color 0.3s;}
    .nav-item .sign-in {color: #fff; background: #2a4d2d; padding: 5px 10px; border-radius: 1px; margin-left: 4px;}
    .nav-item .sign-in:hover {background: #1d3c25;}
    .header {background: #2d6a4f; padding: 10px 0;}
    .header .search-bar {display: flex; align-items: center; justify-content: center; gap: 10px;}
    .header .form-select, .header .form-control, .header .btn {border-radius: 2px; padding: 10px 20px;}
    .header .btn {background: #fff; color: #1e4b33;}
    .header .btn:hover {background: #1e4b33; color: #fff;}
    .content {margin-top: 30px;}
    .card {border: 1px solid #2d6a4f; border-radius: 10px; text-align: center; padding: 20px; margin: 10px; box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);}
    .card-icon {font-size: 50px; color: #2d6a4f;}
    .card-title {font-weight: bold; margin: 15px 0;}
    .card-text {color: #555;}
    .resources-section {padding: 30px 0; background: url('background-image-placeholder.jpg') center/cover;}
    .resources-container {background: #fff; border-radius: 10px; padding: 20px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);}
    .section-title {font-size: 1.25rem; font-weight: bold; margin-bottom: 10px;}
    .section-title span {color: #6b8e23; border-bottom: 3px solid #6b8e23; display: inline-block;}
    .list-group-item {border: none; padding-left: 30px; position: relative;}
    .list-group-item:before {content: ''; position: absolute; left: 0; color: #6b8e23;}
    .recent-submissions .icon {color: #555; margin-right: 10px;}
    .pagination {justify-content: center;}
    .pagination .page-item.active .page-link {background: #6b8e23; border-color: #6b8e23;}
    .footer-section {background: #2d4d2e; color: #fff; padding: 40px 20px;}
    .footer-section .section-title {font-size: 1.25rem; font-weight: bold; color: #fff; margin-bottom: 10px;}
    .footer-section .section-title span {color: #6b8e23; border-bottom: 3px solid #6b8e23; display: inline-block;}
    .footer-section p, .footer-section ul {margin: 0 0 10px; padding: 0; list-style: none; font-size: 0.9rem;}
    .footer-section ul li {margin-bottom: 5px; display: flex; align-items: center;}
    .footer-section ul li span {font-weight: bold; margin-right: 10px; width: 90px;}
    .footer-bottom {background: #1e3c28; color: #fff; padding: 10px 20px; font-size: 0.8rem; text-align: center;}
    .footer-bottom a {color: #6b8e23; text-decoration: none;}
    .footer-bottom a:hover {text-decoration: underline;}
    .hero-section {position: relative; height: 500px; display: flex; align-items: center; justify-content: center; color: #fff; text-align: center; margin-top: 40px;}
    .hero-section::before {content: ''; position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: url('include/BG.jpg') center/cover; filter: brightness(50%); z-index: 1;}
    .hero-overlay {position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.5); z-index: 2;}
    .hero-content {position: relative; z-index: 3;}
    .hero-title {font-size: 3rem; font-weight: bold; margin-bottom: 20px;}
    .hero-description {font-size: 1.25rem; max-width: 800px; margin: 0 auto; line-height: 1.6;}
    .hero-btn {margin-top: 30px; padding: 10px 20px; background: #0A3304; border: none; border-radius: 5px; color: #fff; font-size: 1rem; transition: 0.3s;}
    .hero-btn:hover {background: #08300e;}
    .modal-dialog {max-width: 800px;}
    .form-control-lg {font-size: 1.1rem; padding: 10px;}
    .btn-lg {padding: 12px 20px; font-size: 1.2rem;}
    .nav-tabs .nav-link {font-size: 1.1rem;}
    .modal-header .modal-title {font-size: 1.5rem;}
    .text-dark-green {color: #2c5d3f;}
    .bg-light-green {background: #e9f5ec;}
    .btn-dark-green {background: #2c5d3f; color: #fff;}
    .btn-dark-green:hover {background: #234a32;}
    .form-control {height: 60px; padding: 15px; font-size: 1rem; border:1px solid #256b47;}
    .abstract{ height: 200px;}
    #signIn {height: 100%; margin-bottom: 105px;}
</style>

</head>
<body>

<header class="bg-light border-bottom">
    <nav class="navbar navbar-expand-lg navbar-light container">
        <a class="navbar-brand fw-bold" href="#">
            <img src="include/logo.png" alt="Logo"> 
            <div>
                Digital Archives
                <small>Eastern Samar State University</small>
            </div>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="search_result.php">Search</a></li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="archivalResources" role="button" data-bs-toggle="dropdown" aria-expanded="false">Archival Resources</a>
                    <ul class="dropdown-menu" aria-labelledby="archivalResources">
                        <li><a class="dropdown-item" href="#">Personal Papers</a></li>
                        <li><a class="dropdown-item" href="#">Theses and Dissertations</a></li>
                        <li><a class="dropdown-item" href="#">University Records</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="informationDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Information</a>
                    <ul class="dropdown-menu" aria-labelledby="informationDropdown">
                        <li><a class="dropdown-item" href="#">Steps in Submitting ETDs</a></li>
                        <li><a class="dropdown-item" href="#">IR and ETD Policies</a></li>
                        <li><a class="dropdown-item" href="#">Frequently Asked Questions</a></li>
                    </ul>
                </li>
                <li>
                    <p class="nav-link">
                    Hello, <strong>
                            <?php 
                            // Display the user's name or a fallback if no user is found
                            echo $firstName . ' ' . $lastName;
                            ?>
                        </strong>
                    </p>
                </li>
                <li class="nav-item"><a class="nav-link" href="Access.php">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6" height="20" width="20">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 9V5.25A2.25 2.25 0 0 1 10.5 3h6a2.25 2.25 0 0 1 2.25 2.25v13.5A2.25 2.25 0 0 1 16.5       21h-6a2.25 2.25 0 0 1-2.25-2.25V15m-3 0-3-3m0 0 3-3m-3 3H15" />
                    </svg>
                    Logout</a>
                </li>
            </ul>
        </div>
    </nav>
</header>
<div style="font-size: 19px;" class="container pt-4">Home → Step 2 : Upload Work </div>
    <div class="container mt-5 mb-5">
        <div class="row">
            <!-- Sidebar Steps -->
            <div class="col-md-3">
                <div class="steps">
                    <h4>Steps</h4>
                    <ul class="list-group">
                        <li class="list-group-item">1. Grant Permission</li>
                        <li class="list-group-item active">2. Upload Work</li>
                        <li class="list-group-item ">3.  Uploaded Complete</li>
                    </ul>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-9">
                <div class="form-section">
                    <h4>Upload Work</h4>
                    <form action="insert_data.php" method="POST" enctype="multipart/form-data">
                        <!-- Authors -->
                        <div class="form-group mt-3" id="authors-section">
                            <label for="arch_personal_name" class="form-label">Authors</label>
                            <div id="authors-container">
                                <div class="author-input d-flex align-items-center mb-2">
                                    <input type="text" name="arch_personal_name[]" class="form-control" placeholder="Author Name" required>
                                    <button type="button" class="btn btn-link text-success ms-2 add-author-btn">
                                        <span class="bi bi-plus-circle"></span>+Add
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Resource Title -->
                        <div class="form-group mt-3">
                            <label for="arch_resource_title" class="form-label">Research Title</label>
                            <input type="text" name="arch_resource_title" class="form-control" required>
                        </div>

                        <!-- Abstract -->
                        <div class="form-group mt-3">
                            <label for="arch_abstract" class="form-label">Abstract</label>
                            <textarea name="arch_abstract" class="form-control abstract" rows="3" required></textarea>
                        </div>

                        <!-- Degree Course -->
                        <div class="form-group mt-3">
                            <label for="arch_degree_course" class="form-label">Degree Course</label>
                            <select name="arch_degree_course" class="form-control" required>
                                <option value="">Select Course</option>
                                <option value="Computer Science">Computer Science</option>
                                <option value="Electrical Engineering">Electrical Engineering</option>
                                <option value="Mechanical Engineering">Mechanical Engineering</option>
                                <option value="Civil Engineering">Civil Engineering</option>
                                <option value="Business Administration">Business Administration</option>
                                <option value="Economics">Economics</option>
                            </select>
                        </div>

                        <!-- Keywords -->
                        <div class="form-group mt-3" id="keywords-section">
                            <label for="arch_keywords" class="form-label">Keywords</label>
                            <div id="keywords-container">
                                <div class="keyword-input d-flex align-items-center mb-2">
                                    <input type="text" name="arch_keywords[]" class="form-control" placeholder="Keyword" required>
                                    <button type="button" class="btn btn-link text-success ms-2 add-keyword-btn">
                                        <span class="bi bi-plus-circle"></span>+Add
                                    </button>
                                </div>
                            </div>
                        </div>  

                        <!-- PDF Upload -->
                        <div class="form-group mt-3">
                            <label for="arch_pdf_file" class="form-label">Upload PDF</label>
                            <input type="file" name="arch_pdf_file" accept="application/pdf" class="form-control" required style="background-color:rgba(255, 255, 255, 0);">
                        </div>

                        <!-- Submit Button -->
                        <div class="form-group mt-4 text-end" style="border-radius: 0px;">
                            <input type="submit" class="btn submit-btn" name="personal_data_submit" value="Submit Data">
                        </div>
                    </form> 
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    // Add new author input
    document.addEventListener('click', function (event) {
        if (event.target && event.target.classList.contains('add-author-btn')) {
            const authorsContainer = document.getElementById('authors-container');
            
            // Remove the existing "Add" button from the current row
            const existingButtons = authorsContainer.querySelectorAll('.add-author-btn');
            existingButtons.forEach(btn => btn.remove());

            // Create a new row with an input and an "Add" button
            const newAuthorInput = document.createElement('div');
            newAuthorInput.className = 'author-input d-flex align-items-center mb-2';
            newAuthorInput.innerHTML = `
                <input type="text" name="arch_personal_name[]" class="form-control" placeholder="Author Name" required>
                <button type="button" class="btn btn-link text-success ms-2 add-author-btn">
                    <span class="bi bi-plus-circle"></span> Add
                </button>`;
            authorsContainer.appendChild(newAuthorInput);
        }
    });

    // Add new keyword input
    document.addEventListener('click', function (event) {
        if (event.target && event.target.classList.contains('add-keyword-btn')) {
            const keywordsContainer = document.getElementById('keywords-container');
            
            // Remove the existing "Add" button from the current row
            const existingButtons = keywordsContainer.querySelectorAll('.add-keyword-btn');
            existingButtons.forEach(btn => btn.remove());

            // Create a new row with an input and an "Add" button
            const newKeywordInput = document.createElement('div');
            newKeywordInput.className = 'keyword-input d-flex align-items-center mb-2';
            newKeywordInput.innerHTML = `
                <input type="text" name="arch_keywords[]" class="form-control" placeholder="Keyword" required>
                <button type="button" class="btn btn-link text-success ms-2 add-keyword-btn">
                    <span class="bi bi-plus-circle"></span> Add
                </button>`;
            keywordsContainer.appendChild(newKeywordInput);
        }
    });
</script>

<?php include('include/footer.php'); ?>

