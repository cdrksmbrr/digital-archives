<?php
// Start output buffering to prevent the "headers already sent" issue
ob_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Digital Archives</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <style>
        body { font-family: Arial, sans-serif; background-color: #f0f8f0; color: #2d4d2e; }
        
        /* Navbar */
        .navbar-brand {
            display: flex; align-items: center; font-size: 1.5rem; color: #2a4d2d; text-decoration: none;
        }
        .navbar-brand img { height: 40px; margin-right: 10px; }
        .navbar-brand small { display: block; font-size: 0.8rem; color: #555; margin-top: -5px; }
    
        .nav-link { color: #2a4d2d; font-weight: 500; transition: color 0.3s; }
        .nav-item .sign-in {
            color: #fff; background: #2a4d2d; padding: 5px 10px; border-radius: 1px;margin-left:4px;
        }
        .nav-item .sign-in:hover {
            background: #1d3c25;
        }

        /* Header */
        .header {
            background-color: #2d6a4f;
            padding: 40px 0;
        }
        .header .search-bar {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        .header .form-select, .header .form-control, .header .btn {
            border-radius: 1px;
            padding: 10px 20px;
        }
        .header .btn {
            background-color:rgb(255, 255, 255);
            color: #1e4b33;
        }
        .header .btn:hover {
            background-color: #1e4b33;
            color:white;    
        }

        /* Content */
        .content {
            margin-top: 30px;
        }
        .card {
            border: 1px solid #2d6a4f;
            border-radius: 10px;
            text-align: center;
            padding: 20px;
            margin: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .card-icon {
            font-size: 50px;
            color: #2d6a4f;
        }
        .card-title {
            font-weight: bold;
            margin: 15px 0;
        }
        .card-text {
            color: #555;
        }

        /* Resources Section */
        .resources-section {
            padding: 30px 0;
            background-image: url('background-image-placeholder.jpg'); /* Replace with actual image */
            background-size: cover;
            background-position: center;
        }
        .resources-container {
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .section-title {
            font-size: 1.25rem;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .section-title span {
            color: #6b8e23; /* Accent color */
            border-bottom: 3px solid #6b8e23;
            display: inline-block;
        }
        .list-group-item {
            border: none;
            padding-left: 30px;
            position: relative;
        }
        .list-group-item:before {
            content: '▶';
            position: absolute;
            left: 0;
            color: #6b8e23;
        }
        .recent-submissions .icon {
            color: #555;
            margin-right: 10px;
        }
        .pagination {
            justify-content: center;
        }
        .pagination .page-item.active .page-link {
            background-color: #6b8e23;
            border-color: #6b8e23;
        }

        /* Footer */
        .footer-section {
            margin-top: 300px;
            background-color: #2d4d2e; /* Dark green background */
            color: #ffffff;
            padding: 40px 20px;
        }
        .footer-section .section-title {
            font-size: 1.25rem;
            font-weight: bold;
            color: #ffffff;
            margin-bottom: 10px;
        }
        .footer-section .section-title span {
            color: #6b8e23; /* Accent color */
            border-bottom: 3px solid #6b8e23;
            display: inline-block;
        }
        .footer-section p {
            margin-bottom: 10px;
            font-size: 0.9rem;
        }
        .footer-section ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .footer-section ul li {
            margin-bottom: 5px;
            display: flex;
            align-items: center;
            font-size: 0.9rem;
        }
        .footer-section ul li span {
            font-weight: bold;
            margin-right: 10px;
            display: inline-block;
            width: 90px; /* Align labels */
        }
        .footer-bottom {
            background-color: #1e3c28; /* Darker green */
            color: #ffffff;
            padding: 10px 20px;
            font-size: 0.8rem;
            text-align: center;
        }
        .footer-bottom a {
            color: #6b8e23;
            text-decoration: none;
        }
        .footer-bottom a:hover {
            text-decoration: underline;
        }

        .hero-section {
        position: relative;
        height: 500px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        text-align: center;
        margin-top:40px;
    }

    .hero-section::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-image: url('include/BG.jpg'); /* Replace with your actual background image */
        background-size: cover;
        background-position: center;
        filter: brightness(50%); /* Darkens the background image */
        z-index: 1;
    }

    .hero-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5); /* Adds a semi-transparent overlay for better text contrast */
        z-index: 2;
    }

    .hero-content {
        position: relative;
        z-index: 3;
    }

    .hero-title {
        font-size: 3rem;
        font-weight: bold;
        margin-bottom: 20px;
    }

    .hero-description {
        font-size: 1.25rem;
        max-width: 800px;
        margin: 0 auto;
        line-height: 1.6;
    }

    .hero-btn {
        margin-top: 30px;
        padding: 10px 20px;
        background-color: #0A3304; /* Dark green button color */
        border: none;
        border-radius: 5px;
        color: white;
        font-size: 1rem;
        transition: background-color 0.3s;
    }

    .hero-btn:hover {
        background-color: #08300e; /* Darker shade on hover */
    }

    .modal-dialog {
    max-width: 800px; /* Set a wider modal width */
  }

  .form-control-lg {
    font-size: 1.1rem; /* Larger font size for form inputs */
    padding: 10px; /* More padding for inputs */
  }

  .btn-lg {
    padding: 12px 20px; /* Larger button padding */
    font-size: 1.2rem; /* Larger font size for buttons */
  }

  .nav-tabs .nav-link {
    font-size: 1.1rem; /* Larger font size for tabs */
  }

  .modal-header .modal-title {
    font-size: 1.5rem; /* Larger modal title */
  }

  .text-dark-green {
        color: #2c5d3f;
    }

    .bg-light-green {
        background-color: #e9f5ec;
    }

    .btn-dark-green {
        background-color: #2c5d3f;
        color: #fff;
    }

    .btn-dark-green:hover {
        background-color: #234a32;
    }

    /* Custom input styling */
.form-control {
    height: 45px; /* Increase the height of input fields */
    padding: 12px; /* Increase padding for a more spacious input */
    font-size: 1rem; /* Adjust font size if needed */
}
#signIn{
    height:100%;
    margin-bottom:105px;
}
  
    </style>
</head>
<body>
