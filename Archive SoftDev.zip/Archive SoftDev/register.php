<?php
include 'connect.php';  // Include your database connection

session_start(); // Start session to track user login state

// Sign-Up Process
if (isset($_POST['signUp'])) {
    $firstName = $_POST['fName'];
    $lastName = $_POST['lName'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT); // Hash the password

    // Prepared statement to check if the email already exists in the users table
    $checkEmail = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $checkEmail->bind_param("s", $email);
    $checkEmail->execute();
    $result = $checkEmail->get_result();

    if ($result->num_rows > 0) {
        echo "<script>
        if(confirm('Email Address Already Exists!')){
          window.location.href='Access.php';
        }
      </script>";
    } else {
        // Prepared statement to insert user data into the users table
        $insertQuery = $conn->prepare("INSERT INTO users (firstName, lastName, email, password) VALUES (?, ?, ?, ?)");
        $insertQuery->bind_param("ssss", $firstName, $lastName, $email, $hashedPassword);

        if ($insertQuery->execute()) {
            // Redirect to Access.php after successful registration
            header("Location: Access.php");
            exit();
        } else {
            echo "Error: " . $insertQuery->error;
        }
    }
}

if (isset($_POST['signIn'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $sql = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $sql->bind_param("s", $email);
    $sql->execute();
    $result = $sql->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) { 
            $_SESSION['user_id'] = $row['user_id']; 
            $_SESSION['email'] = $row['email']; 
            header("Location: index.php"); 
            exit();
        } else {
            echo "<script>
            if(confirm('Incorrect password. Try Again!')){
                window.location.href='Access.php';
            }
            </script>";
        }
    } else {
        echo "<script>
        if(confirm('Email not found. Try Again!')){
            window.location.href='Access.php';
        }
        </script>";
    }
}

?>
