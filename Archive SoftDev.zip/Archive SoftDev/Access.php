<?php include('connect.php'); ?>
<?php include('header.php'); ?>

<header class="bg-light border-bottom">
    <nav class="navbar navbar-expand-lg navbar-light container">
        <a class="navbar-brand fw-bold" href="#">
            <img src="include/logo.png" alt="Logo">
            <div>
                Digital Archives
                <small>Eastern Samar State University</small>
            </div>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="#">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Search</a></li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="archivalResources" role="button" data-bs-toggle="dropdown" aria-expanded="false">Archival Resources</a>
                    <ul class="dropdown-menu" aria-labelledby="archivalResources">
                        <li><a class="dropdown-item" href="#">Personal Papers</a></li>
                        <li><a class="dropdown-item" href="#">Theses and Dissertations</a></li>
                        <li><a class="dropdown-item" href="#">University Records</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="informationDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Information</a>
                    <ul class="dropdown-menu" aria-labelledby="informationDropdown">
                        <li><a class="dropdown-item" href="#">Steps in Submitting ETDs</a></li>
                        <li><a class="dropdown-item" href="#">IR and ETD Policies</a></li>
                        <li><a class="dropdown-item" href="#">Frequently Asked Questions</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>
</header>

<div class="main-content py-5">
    <!-- Sign-up Form -->
    <div class="container" id="signupForm" style="display:none;">
        <div class="row justify-content-center">
            <div class="col-lg-6 col-md-8 col-sm-10">
                <div class="text-center mb-4">
                    <img src="include/logo.png" alt="Logo" class="img-fluid" style="max-width: 100px;">
                    <h1 class="h4 fw-bold text-dark-green">Create Your Account</h1>
                    <p class="text-muted">Join the Eastern Samar State University community.</p>
                </div>
                <form method="post" action="register.php">
                    <div class="mb-3">
                        <label for="fName" class="form-label">First Name</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-user"></i></span>
                            <input type="text" class="form-control" name="fName" id="fName" placeholder="First Name" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="lName" class="form-label">Last Name</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-user"></i></span>
                            <input type="text" class="form-control" name="lName" id="lName" placeholder="Last Name" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                            <input type="email" class="form-control" name="email" id="email" placeholder="Email" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-lock"></i></span>
                            <input type="password" class="form-control" name="password" id="password" placeholder="Password" required>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-dark-green w-100" name="signUp">Sign Up</button>
                </form>
                <p class="mt-3 text-center text-muted">
                    By creating an account, you agree to our <a href="#" class="text-decoration-none text-dark-green">Terms of Service</a> and <a href="#" class="text-decoration-none text-dark-green">Privacy Policy</a>.
                </p>
                <p class="text-center">Already have an account? <button id="signInButton" class="btn btn-link text-dark-green">Sign In</button></p>
            </div>
        </div>
    </div>

    <!-- Sign-in Form -->
    <div class="container" id="signInForm">
        <div class="row justify-content-center">
            <div class="col-lg-6 col-md-8 col-sm-10">
                <form method="post" action="register.php">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                            <input type="email" class="form-control" name="email" id="email" placeholder="Email" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-lock"></i></span>
                            <input type="password" class="form-control" name="password" id="password" placeholder="Password" required>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-dark-green w-100" name="signIn">Sign In</button>
                    <a href="" class="d-block text-center mt-2">Forgot Password?</a>
                </form>
                <p class="text-center">Don't have an account yet? <button id="signUpButton" class="btn btn-link text-dark-green">Sign Up</button></p>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
// Toggle between Sign-up and Sign-in forms
document.getElementById('signInButton').addEventListener('click', function() {
    document.getElementById('signupForm').style.display = 'none';
    document.getElementById('signInForm').style.display = 'block';
});

document.getElementById('signUpButton').addEventListener('click', function() {
    document.getElementById('signInForm').style.display = 'none';
    document.getElementById('signupForm').style.display = 'block';
});
</script>

<?php
// Include connection file
include('connect.php');

// Sign-Up Process
if (isset($_POST['signUp'])) {
    $firstName = $_POST['fName'];
    $lastName = $_POST['lName'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT); // Hash the password

    // Prepared statement to check if the email already exists in the users table
    $checkEmail = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $checkEmail->bind_param("s", $email);
    $checkEmail->execute();
    $result = $checkEmail->get_result();

    if ($result->num_rows > 0) {
        echo "<script>
        if(confirm('Email Address Already Exists!')){
          window.location.href='Access.php';
        }
      </script>";
    } else {
        // Prepared statement to insert user data into the users table
        $insertQuery = $conn->prepare("INSERT INTO users (firstName, lastName, email, password) VALUES (?, ?, ?, ?)");
        $insertQuery->bind_param("ssss", $firstName, $lastName, $email, $hashedPassword);

        if ($insertQuery->execute()) {
            // Redirect to Access.php after successful registration
            header("Location: Access.php");
            exit();
        } else {
            echo "Error: " . $insertQuery->error;
        }
    }
}

// Sign-In Process
if (isset($_POST['signIn'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepared statement to fetch user data from the users table based on email
    $sql = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $sql->bind_param("s", $email);
    $sql->execute();
    $result = $sql->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) { // Verify the password
            $_SESSION['user_id'] = $row['user_id']; // Start a session with the user's ID
            header("Location: home.php"); // Redirect to the dashboard after successful login
            exit();
        } else {
            echo "<script>alert('Incorrect password');</script>";
        }
    } else {
        echo "<script>alert('No user found with that email');</script>";
    }
}
?>

<?php include('include/footer.php'); ?>
