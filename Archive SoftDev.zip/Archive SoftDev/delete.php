<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Include the database connection file
include('connect.php');

// Check if the 'data_id' parameter is passed in the URL
if (isset($_GET['data_id'])) {
    $data_id = $_GET['data_id'];
    $user_id = $_SESSION['user_id'];

    // Prepare the SQL query to delete the resource
    $query = "DELETE FROM `insert_data` WHERE `data_id` = ? AND `user_id` = ?";

    // Prepare the statement
    if ($stmt = $conn->prepare($query)) {
        // Bind the parameters to the query
        $stmt->bind_param("ii", $data_id, $user_id);

        // Execute the query
        if ($stmt->execute()) {
            // Redirect with success message
            header("Location: view-uploads.php?message_success=Resource deleted successfully");
        } else {
            // Redirect with error message
            header("Location:  view-uploads.php?message=Error deleting resource");
        }

        // Close the statement
        $stmt->close();
    } else {
        // Redirect with error message if the query couldn't be prepared
        header("Location:  view-uploads.php?message=Error preparing delete query");
    }
} else {
    // Redirect with error message if 'data_id' is not set
    header("Location:  view-uploads.php?message=Invalid resource ID");
}

exit();
?>
